﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class trucklogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void truckLoginButton_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=stillwaterfoodtruck.database.windows.net; Initial Catalog=FoodTruckDB;Persist Security Info=True;User ID=foodtruckadmin;Password=password1!");
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from dbo.[truck] where ownerEmail=@ownerEmail and ownerPassword=@ownerPassword", con);
        cmd.Parameters.AddWithValue("@ownerEmail", ownerEmailTextbox.Text);
        cmd.Parameters.AddWithValue("@ownerPassword", ownerPasswordTextbox.Text);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Response.Redirect("truckdashboard.aspx");
        }
        else
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
            Response.Redirect("trucklogin.aspx");
        }
    }
}